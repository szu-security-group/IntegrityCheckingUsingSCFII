package com.fchen_group.TPDSInScf.Run;

import java.io.IOException;

import static com.fchen_group.TPDSInScf.Run.Client.auditTask;

/**
 * 用来进行性能测试
 * The Benchmark class,  used to execute the performance experiment
 *
 * @author jquan, fchen-group of SZU
 * @Version 2.0 2021.12.02
 * @Time 2021.3 - 2021.12
 */
public class Benchmark {
    public static void main(String args[]) throws IOException {
        String[] files =
                {       "E:\\project\\file\\10MB.txt",
                        "E:\\project\\file\\20MB.txt",
                        "E:\\project\\file\\50MB.txt",
                        "E:\\project\\file\\100MB.txt",
                        "E:\\project\\file\\200MB.txt",
                        "E:\\project\\file\\500MB.txt",
                };

        int length =files.length;
        System.out.println(length);
        for (int i=0;i<length;i++){
            auditTask(files[i], 255, 223, length, 16);
        }
    }


}
