package com.fchen_group.TPDSInScf.Utils;

import com.tencentcloudapi.common.Credential;
import com.tencentcloudapi.common.exception.TencentCloudSDKException;
import com.tencentcloudapi.common.profile.ClientProfile;
import com.tencentcloudapi.scf.v20180416.ScfClient;
import com.tencentcloudapi.scf.v20180416.models.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

public class TenYunControl  {


    static String cosConfigFilePath = "E:\\研究生\\组\\研一上\\0\\IntegrityCheckingUsingSCF-master\\Properties";
    //static String cosConfigFilePath = "E:\\project\\IntegrityCheckingUsingSCF-master\\Properties";
    public static ScfClient createClient() throws IOException {
        String secretId;
        String secretKey;
        String region;
        FileInputStream propertiesFIS = new FileInputStream(cosConfigFilePath);
        Properties properties = new Properties();
        properties.load(propertiesFIS);
        propertiesFIS.close();
        secretId = properties.getProperty("secretId");
        secretKey = properties.getProperty("secretKey");
        region = properties.getProperty("regionName");
        Credential cred = new Credential(secretId, secretKey);
        ClientProfile clientProfile = new ClientProfile();
        ScfClient client = new ScfClient(cred, region, clientProfile);

        return client;
    }

    public void createFunction(String projectDir,String mavenExecutable,String functionName, String handler, String runtime, int memorySize, int timeout, String region) throws IOException {
        String jarFilePath=projectDir+"\\target\\TPDSInSCF-1.0-SNAPSHOT_Benchmark-jar-with-dependencies.jar";

        runMavenCommand(projectDir,mavenExecutable);
        System.out.println("ok");
        createFunctionWithJar(jarFilePath,functionName,handler,runtime,memorySize,timeout,region);
    }
    public void createFunctionWithJar(String jarFilePath, String functionName, String handler, String runtime, int memorySize, int timeout, String region) {
        try {
            ScfClient client = createClient();
            client.setRegion(region);
            CreateFunctionRequest req = new CreateFunctionRequest();
            req.setFunctionName(functionName);
            req.setHandler(handler);
            req.setRuntime(runtime);
            req.setMemorySize((long) memorySize);
            req.setTimeout((long) timeout);
            // 读取JAR文件的字节内容
            byte[] jarBytes = Files.readAllBytes(Paths.get(jarFilePath));

            // 将JAR文件内容编码为Base64字符串
            String jarBase64 = java.util.Base64.getEncoder().encodeToString(jarBytes);
            // 设置Code对象
            Code code = new Code();
            code.setZipFile(jarBase64);
            req.setCode(code);

            // 创建函数
            CreateFunctionResponse resp = client.CreateFunction(req);
            System.out.println(CreateFunctionResponse.toJsonString(resp));

        } catch (TencentCloudSDKException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static void runMavenCommand(String projectDir,String mavenExecutable) throws IOException {
        // 替换为你 Maven 可执行文件的完整路径


        ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.directory(new File(projectDir));
        processBuilder.command(mavenExecutable, "clean", "package", "-Pproduction-Ten");

        Process process = processBuilder.start();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading Maven output", e);
        }

        try {
            int exitCode = process.waitFor();
            if (exitCode != 0) {
                throw new RuntimeException("Maven command failed with exit code " + exitCode);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Maven command was interrupted", e);
        }
    }

    public String invoke(String testData) {
        String result = null;
        try {
            String functionName;
            FileInputStream propertiesFIS = new FileInputStream(cosConfigFilePath);
            Properties properties = new Properties();
            properties.load(propertiesFIS);
            propertiesFIS.close();
            functionName = properties.getProperty("functionName");
            ScfClient client = createClient();
            InvokeFunctionRequest req = new InvokeFunctionRequest();
            req.setFunctionName(functionName);

            req.setEvent(testData);
            InvokeFunctionResponse output = client.InvokeFunction(req);
            Result outputResult = output.getResult();
            result = outputResult.getRetMsg();
            System.out.println(result);
        } catch (TencentCloudSDKException e) {
            System.out.println("???");
            System.out.println("Error: " + e.getMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

//TenYunControl tenYunControl = new TenYunControl();
    //tenYunControl.invoke("{\"PARITY_SHARDS\":32,\"DaTA_SHARDS\":223,\"challengeData\":{\"coefficients\":\"r9bK2dM59ZZqoWRcBX6W6brUuIXQtvSr/1Nu47kSg2dZEuO02Ru/1Ah+KQlzDJ2ZDzLHCaymsNTNVdjc1qGm6nC+qTwml4MrYgz7ZdUgvngqL19V9ukYYlAEdeOJin3+Sbox05OKBWR1TnxsRJhXXbZ1fC9vMGzZKJEJ8+V9F34AjRg6bFt7KKC9PGpt/ekUXo9BHY8jap+WN41b0p+rLfQZYp3zz0VuJ1PiuRMnodRVYooo/2iN5v9MG5yMjXykSGVmBdu5t7y0IFx3iybi/c+9ofIfdZNIb+Hm1iK0xoNkaAOazXA4dNF4n7E+hjiUhfZrroEtPNkT8NHG+Payk3P2hHXmHEuYb6exqirYPFM1k5j1bFtrk74fitFFpofE47D0YTfRRKZiOgBNYpROzCAJrYxa7hU9ZRNNi5bFkd/nC8S/RHa7seLZSRuJRztVi4j6EXoOpUGjSrbDSaKA6PhiAgGGhPdWC7GZhlsRLdo+2dBDLv+4jTaSOP0Tui3NUB2RmOmO8hJeZhfEJXN61ghHgAKO0XUqgAQlA3vxCgdt4gf5Tp2sNz6krfJIbjHROJ78cuTmwzEGmmEsXBqxPpXeOkMKV+ICdDHJng==\",\"index\":[42709,40716,37557,20109,19632,40071,27848,23996,3320,45407,18758,31073,9393,6868,45954,26286,23672,40087,36762,10026,17929,6043,12978,23291,34509,35307,3459,33953,7085,12801,12311,18662,17680,42427,13455,2342,25917,25615,46033,16814,45172,24554,9649,14047,44771,33715,40971,16475,5731,15088,43323,36096,40646,30676,526,369,4599,16833,45115,25864,24897,30372,21718,36632,11699,12321,16121,4337,32541,16092,34617,36260,26196,39136,9288,35502,43994,41970,25106,10372,32415,35570,22112,40341,22853,37566,22373,14914,1441,11536,26241,45623,7692,28267,18537,46920,194,7538,4122,26690,14672,8829,23872,15938,21385,13818,1262,1365,41784,19258,3794,40156,41623,38240,13174,45930,33162,28178,1209,41336,2974,11056,27467,27150,38772,6160,34272,19779,3620,29129,20310,13765,4476,11625,26094,18739,23033,9360,22988,8051,3665,16166,42020,37169,12372,18960,33231,45826,22477,37600,35865,14733,19551,33277,12047,28087,16882,43192,35804,17085,29899,10284,1589,36485,32459,44484,12494,18392,12489,5072,28204,43212,28542,16434,8804,316,15667,8421,21558,14750,18000,18258,28930,9394,23393,32389,18398,35394,34098,18615,45524,45911,10776,40251,46938,1676,21569,21911,8399,2888,43787,28256,26022,38092,12219,6613,12827,28062,31639,8388,4911,16290,17025,28610,9728,43973,6869,16095,11161,18614,42487,45049,44482,31546,22899,30143,15406,35768,41062,24814,41,46039,36773,24895,26079,41424,42179,24065,33645,45221,22003,46210,36348,45132,37232,5308,12788,7682,3952,35714,20876,20767,39815,12718,6988,31723,41037,34981,21957,37917,21200,35560,26209,34158,43880,36097,303,14767,23972,44658,23170,21028,9202,20853,26612,44262,18927,34211,34594,7220,30229,43168,36223,32011,41734,45466,39417,33525,3519,31357,14431,45901,42818,34673,33982,16538,41460,38132,15852,6683,21984,6278,18504,42608,40479,38071,15676,3333,27502,22099,24500,35348,41547,5498,43815,19805,34077,12291,33396,16338,26872,22198,46526,23423,10549,28247,41346,9209,3537,13720,19593,33959,3512,9615,5959,5831,25532,6116,8168,19064,6179,19387,34214,43319,1956,35757,41921,43501,26554,44722,20739,31768,44575,6592,27121,580,22945,33333,25308,40534,36880,29807,31517,9862,42570,13334,31559,27014,1648,8022,27594,18910,33939,15396,30574,10142,28397,31259,18957,10859,28452,21430,4181,7530,43047,8325,27689,6612,9533,24187,19710,20960,12888,20912,11874,4461,18401,46303,7250,12890,9351,3635,38285,19479,25940,36425,41254,6249,44502,42449,5735,33570,9980,8545,38684,38521,31851,27602,10586,1825,23538,35671,2452,9410,10478,5295,29454,7262,44756,41517,18232,4221,8256,12339,39597,1193,46443,31307,44041,43719,17284,24462,1095,42742,6496,13237,29451,3500,2500,29295,35132,38733,34006,42568,19898,21704,31773,14648,45478,27213]},\"bucketName\":\"spin-baby-1322020954\",\"regionName\":\"ap-tokyo\",\"secretId\":\"AKIDzud7ShlnXH40sdUOBoMo6DmDVdifUCpH\",\"secretKey\":\"MZbUQI2c5ZwQxOj5TlttgLrFPXZO2cEl\",\"threadNum\":12}\n");


    public static void main(String[] args) throws Exception {
        String projectDir = "E:\\研究生\\组\\研一上\\0\\IntegrityCheckingUsingSCF-master";
        String mavenExecutable = "E:\\project\\apache-maven-3.9.5\\bin\\mvn.cmd";
        String functionName = "task2-112";
        String handler = "com.fchen_group.TPDSInScf.Run.TenHandle::mainHandler";
        String runtime = "Java8";
        int memorySize = 128;
        int timeout = 100;
        String region = "ap-tokyo";
        String jarFilePath=projectDir+"\\target\\TPDSInSCF-1.0-SNAPSHOT_Benchmark-jar-with-dependencies.jar";
        TenYunControl tenYunControl=new TenYunControl();
        //tenYunControl.createFunctionWithJar(jarFilePath,functionName,handler,runtime,memorySize,timeout,region);
        tenYunControl.createFunction(projectDir,mavenExecutable,functionName,handler,runtime,memorySize,timeout,region);
    }
}
